function fun1()
{
	var name=document.f1.n1.value;
	var ph=document.f1.n2.value;
	var pwd=document.f1.n3.value;
    var city=document.f1.n4.value;
    var mail=document.f1.n5.value;
	if(name=="")
	{
		document.getElementById('s1').innerHTML='*please fill ur name';
		document.getElementById('s1').style.color='red';
		return false;
	}
	if(ph=="")
	{
		document.getElementById('s2').innerHTML="*please fill ur phno";
		document.getElementById('s2').style.color="red";
		return false;
	}
	if(pwd=="")
	{
		document.getElementById('s3').innerHTML="*please fill ur password";
		document.getElementById('s3').style.color="red";
		return false;
	}
	if(city=="")
	{
		document.getElementById('s4').innerHTML='*please fill ur name';
		document.getElementById('s4').style.color='red';
		return false;
	}
	if(mail=="")
	{
		document.getElementById('s5').innerHTML='*please fill ur mail';
		document.getElementById('s5').style.color='red';
		return false;
	}
	
	else
	{
		
		alert("Ur data is accepted");
		return true;
	}
}
function f2(){
	var x=confirm('are u sure to reset??');
	if(x==true){
		return true;
	}
	else{
		return false;
	}
}
function fun3()
{
	var hid=document.f1.n1.value;
	var hname=document.f1.n2.value;
	var hloc=document.f1.n3.value;
	var hfair=document.f1.n4.value;
	var hmail=document.f1.n5.value;
	var hpwd=document.f1.n6.value;
	var hcont=document.f1.n7.value;
   
	if(hid=="")
	{
		document.getElementById('s1').innerHTML='*please fill ur id';
		document.getElementById('s1').style.color='red';
		return false;
	}
	if(hname=="")
	{
		document.getElementById('s2').innerHTML="*please fill ur name";
		document.getElementById('s2').style.color="red";
		return false;
	}
	if(hloc=="")
	{
		document.getElementById('s3').innerHTML="*please fill ur location";
		document.getElementById('s3').style.color="red";
		return false;
	}
	if(hfair=="")
	{
		document.getElementById('s4').innerHTML="*please fill ur hotel fair";
		document.getElementById('s4').style.color="red";
		return false;
	}
	if(hmail=="")
	{
		document.getElementById('s5').innerHTML="*please fill ur hotel mail";
		document.getElementById('s5').style.color="red";
		return false;
	}
	if(hpwd=="")
	{
		document.getElementById('s6').innerHTML="*please fill ur hotel pswd";
		document.getElementById('s6').style.color="red";
		return false;
	}
	if(hcont=="")
	{
		document.getElementById('s7').innerHTML="*please fill ur hotel contact";
		document.getElementById('s7').style.color="red";
		return false;
	}
	else
	{
		
		alert("Ur data is accepted");
		return true;
	}
}
function fun4()
{
	var cid=document.f1.n1.value;
	var ph=document.f1.n2.value;
	
	if(cid=="")
	{
		document.getElementById('s1').innerHTML="*please fill ur id";
		document.getElementById('s1').style.color="red";
		return false;
	}
	if(pwd=="")
	{
		document.getElementById('s2').innerHTML="*please fill ur password";
		document.getElementById('s2').style.color="red";
		return false;
	}
	else
	{
		
		alert("Ur data is accepted");
		return true;
	}
}