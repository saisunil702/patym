package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.Hotel;
import Model.HotelDao;
public class HotelController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get data hotel html form
				int h1=Integer.parseInt(request.getParameter("n1"));
				String h2=request.getParameter("n2");
				
				String h3=request.getParameter("n3");
				float h4=Float.parseFloat(request.getParameter("n4"));
				String h5=request.getParameter("n5");
				String h6=request.getParameter("n6");
				long h7=Long.parseLong(request.getParameter("n7"));
				//create model object
				Hotel ob=new Hotel();
				ob.setHid(h1);
				ob.setHname(h2);
				ob.setHlocation(h3);
				ob.setHfair(h4);
				ob.setHmail(h5);
				ob.setHpassword(h6);
				ob.setHcont(h7);
				
				//bm calling
				if(HotelDao.checkhid(h1))
				{
					RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/HotelView/hotelcancel.jsp");
					rd.forward(request, response);
				}
				else
				{
					int m=HotelDao.addHotelDetails(ob);
					request.setAttribute("k1",ob);
					RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/HotelView/hotelok.jsp");
					rd.forward(request, response);
				}
				
			}

		}