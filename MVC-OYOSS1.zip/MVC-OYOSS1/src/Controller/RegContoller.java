package Controller;

import java.io.*;
import java.util.Random;

import javax.servlet.*;
import javax.servlet.http.*;

import Model.*;
public class RegContoller extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Random rand = new Random();
		int n = rand.nextInt(99999) + 100000;
		
		//1.get dat from html form
				String fn=request.getParameter("n1");
				String ph1=request.getParameter("n2");
				//long ph=Long.parseLong(ph1);
				long ph=Long.parseLong(request.getParameter("n2"));
				String pwd=request.getParameter("n3");
				String lctn=request.getParameter("n4");
				String mail=request.getParameter("n5");
				int cid=n;
				//2.creating model object
				Hotel ob=new Hotel();
				ob.setFullname(fn);
				ob.setPhoneno(ph);
				ob.setPassword(pwd);
				ob.setCity(lctn);
				ob.setMail(mail);
				ob.setCid(cid);
				//bm calling
				if(CustomerDao.checkCid(cid)&&CustomerDao.checkPswd(pwd))
				{
					RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/view/Regcancel.jsp");
					rd.forward(request, response);
				}
				else
				{
					int r=CustomerDao.addDetails(ob);
					request.setAttribute("k1", ob);
					RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/view/Regok.jsp");
					rd.forward(request, response);
				
				}

	}

}
