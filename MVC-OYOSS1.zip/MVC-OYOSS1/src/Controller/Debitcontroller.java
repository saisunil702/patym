package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.Hotel;
import Model.HotelDao;


public class Debitcontroller extends HttpServlet {

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long p1=Long.parseLong(request.getParameter("n1"));
		int p2=Integer.parseInt(request.getParameter("n2"));
		float p3=Float.parseFloat(request.getParameter("amnt"));
		int p4=Integer.parseInt(request.getParameter("hid"));
		 Hotel ob=new Hotel();
		HttpSession hs1=request.getSession();
		
		
		System.out.println("amnt="+p4);
		
		ob.setCardno(p1);
		ob.setCvv(p2);
		ob.setTxamount(p3);
		ob.setHid(p4);
		boolean r=HotelDao.debitCard();
	    request.setAttribute("p1", ob);
		RequestDispatcher rd=request.getRequestDispatcher("Debitcard.jsp");
		rd.include(request, response);
	}

}
