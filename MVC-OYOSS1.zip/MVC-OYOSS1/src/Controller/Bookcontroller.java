package Controller;
import java.io.*;
import java.util.*;
import java.lang.*;
import javax.servlet.*;
import javax.servlet.http.*;
import Model.*;

public class Bookcontroller extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int p2=Integer.parseInt(request.getParameter("n1"));
		int p3=Integer.parseInt(request.getParameter("n2"));
		int n=p2+p3;
		String p4=request.getParameter("n3");
		String p5=request.getParameter("n4");
		String p6=request.getParameter("n5");
		
        Hotel ob=new Hotel();
        HttpSession hs=request.getSession();
		Integer cid=(Integer)hs.getAttribute("cid");
		
		System.out.println("cid="+cid);
		
		ob.setBookedby(cid);
		ob.setPeople(n);
		ob.setDateofvisiting(p4);
		ob.setCheckintime(p5);
		ob.setCheckouttime(p6);
		
		int r=HotelDao.saveBooking(ob);
	    request.setAttribute("k1", ob);
		RequestDispatcher rd=request.getRequestDispatcher("confirm.jsp");
		rd.include(request, response);
		
	}


}
