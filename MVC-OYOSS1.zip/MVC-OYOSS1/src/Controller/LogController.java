package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.CustomerDao;
import Model.Hotel;

public class LogController extends HttpServlet {
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get data from form
				int cid=Integer.parseInt(request.getParameter("n1"));
				String pwd=request.getParameter("n2");
				//creating model obj
				Hotel ob=new Hotel();
				ob.setCid(cid);
				ob.setPassword(pwd);
				//bm calling
				if(CustomerDao.checkCid(cid)&&CustomerDao.checkPswd(pwd))
				{
					request.setAttribute("k1", ob);
					RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/view/Logok.jsp");
					rd.include(request, response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/view/Logcancel.jsp");
					rd.forward(request, response);
				}
				
			}

		}
