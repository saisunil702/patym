package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.MyCon;



public class Edit extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession hs=request.getSession();
		String hid=(String)hs.getAttribute("key1");
		
		try {
			Connection con=MyCon.getMycon();
			PreparedStatement pst=con.prepareStatement("select * from hotels where hid=?");
			pst.setString(1, hid);
			ResultSet rs=pst.executeQuery();
			ResultSetMetaData rsmd=rs.getMetaData();
			int cc=rsmd.getColumnCount();
			while(rs.next())
			{
				out.print("<center><h1>Hrello mr"+hid+"Here is your Edit Form</h1></center");
				out.println("<html><body bgcolor='aqua'><center><form action='url4'><table border='3px' bordercolor='orange' cellspacing='5px'cellpadding='5px color='silver'>");
	
	        out.print("<tr><td>HotelId:</td><td><input type='number' name='n1' value="+rs.getString(1)+" readonly></td></tr>");
	        out.print("<tr><td>HotelName:</td><td><input type='text' name='n2' value="+rs.getString(2)+"></td></tr>");
	        out.print("<tr><td></td>HotelContact:<td><input type='number' name='n7' value="+rs.getString(7)+"></td></tr>");
	        out.print("<tr><td>HotelFair:</td><td><input type='number' name='n4' value="+rs.getString(4)+"></td></tr>");
	        out.print("<tr><td>HotelMail:</td><td><input type='text' name='n5' value="+rs.getString(5)+"></td></tr>");
	        out.print("<tr><td>HotelLocation:</td><td><select name='n3' value="+rs.getString(3)+"><option value='Serach Location'>"+
	        		"Serach Location</option>"+
	        		"<option value='Ameerpet'e food>Ameerpet</option>"+
					"<opton value='SrNagar'>SrNagar</option>"+
	                "<option value='SanathNagar'>SanathNagar</option>"+
					"</td></tr></select>");
	        out.print("<tr><td>HotelPassword:</td><td><input type='password' name='n6' value="+rs.getString(6)+"></td></tr>");
	        out.print("<tr><td><input type='submit'  value='Update'></td></tr>");

		}}
	   catch(Exception e) 
	   {
					e.printStackTrace();
	   }
		out.println("</form></center></table></body></html>");
	}

}
