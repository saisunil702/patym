package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

public class CustomerDao 
{
	static Connection con=MyCon.getMycon();
	        //bm2--for new customer
			public static boolean checkCid(int cid)
			{
				boolean temp=false;
				try 
				{
					PreparedStatement pst=con.prepareStatement("select cid from customers where cid=?");
					pst.setInt(1, cid);
					ResultSet rs=pst.executeQuery();
					temp=rs.next();
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
				return temp;
				
			}
			//bm for login
			public static boolean checkPswd(String pwd)
			{
				boolean temp=false;
				try 
				{
					PreparedStatement pst=con.prepareStatement("select password from customers where password=?");
					pst.setString(1, pwd);
					ResultSet rs=pst.executeQuery();
					temp=rs.next();
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
				return temp;
				
			}
			//bm2--for new customer
			public static int addDetails(Hotel ob)
			{
				int temp=0;
				try
				{
					PreparedStatement pst=con.prepareStatement("insert into customers values(?,?,?,?,?,?)");
					pst.setString(1, ob.getFullname());
					pst.setLong(2, ob.getPhoneno());
					pst.setString(3, ob.getPassword());
					pst.setString(4, ob.getCity());
					pst.setString(5, ob.getMail());
					pst.setInt(6, ob.getCid());
					
					temp=pst.executeUpdate();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
				return temp;
				
			
			}		
			
	}


