package Model;

public class Hotel {
private int hid,cid,bookedby,noofadults,noofchilds,people,txid,txby,cvv;
private String hname,hlocation,hpassword,fullname,hmail,password,city,mail;
private String dateofvisiting,checkouttime,checkintime,txtime;
private long hcont,phoneno,cardno;
private float hfair,txamount;
public int getHid() {
	return hid;
}
public void setHid(int hid) {
	this.hid = hid;
}
public String getHname() {
	return hname;
}
public void setHname(String hname) {
	this.hname = hname;
}
public String getHlocation() {
	return hlocation;
}
public void setHlocation(String hlocation) {
	this.hlocation = hlocation;
}
public String getHpassword() {
	return hpassword;
}
public void setHpassword(String hpassword) {
	this.hpassword = hpassword;
}
public String getFullname() {
	return fullname;
}
public void setFullname(String fullname) {
	this.fullname = fullname;
}
public String getHmail() {
	return hmail;
}
public void setHmail(String hmail) {
	this.hmail = hmail;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getMail() {
	return mail;
}
public void setMail(String mail) {
	this.mail = mail;
}

public long getHcont() {
	return hcont;
}
public void setHcont(long hcont) {
	this.hcont = hcont;
}
public long getPhoneno() {
	return phoneno;
}
public void setPhoneno(long phoneno) {
	this.phoneno = phoneno;
}
public float getHfair() {
	return hfair;
}
public void setHfair(float hfair) {
	this.hfair = hfair;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public int getBookedby() {
	return bookedby;
}
public void setBookedby(int bookedby) {
	this.bookedby = bookedby;
}
public int getNoofadults() {
	return noofadults;
}
public void setNoofadults(int noofadults) {
	this.noofadults = noofadults;
}
public int getNoofchilds() {
	return noofchilds;
}
public void setNoofchilds(int noofchilds) {
	this.noofchilds = noofchilds;
}
public String getDateofvisiting() {
	return dateofvisiting;
}
public void setDateofvisiting(String dateofvisiting) {
	this.dateofvisiting = dateofvisiting;
}
public String getCheckintime() {
	return checkintime;
}
public void setCheckintime(String checkintime) {
	this.checkintime = checkintime;
}
public String getCheckouttime() {
	return checkouttime;
}
public void setCheckouttime(String checkouttime) {
	this.checkouttime = checkouttime;
}
public int getPeople() {
	return people;
}
public void setPeople(int people) {
	this.people = people;
}
public int getTxid() {
	return txid;
}
public void setTxid(int txid) {
	this.txid = txid;
}
public int getTxby() {
	return txby;
}
public void setTxby(int txby) {
	this.txby = txby;
}
public String getTxtime() {
	return txtime;
}
public void setTxtime(String txtime) {
	this.txtime = txtime;
}
public long getCardno() {
	return cardno;
}
public void setCardno(long cardno) {
	this.cardno = cardno;
}
public float getTxamount() {
	return txamount;
}
public void setTxamount(float txamount) {
	this.txamount = txamount;
}
public int getCvv() {
	return cvv;
}
public void setCvv(int cvv) {
	this.cvv = cvv;
}

}