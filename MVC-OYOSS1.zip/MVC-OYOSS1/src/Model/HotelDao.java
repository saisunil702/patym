package Model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HotelDao 
{
	static Connection con=MyCon.getMycon();
	//bm1--for hotel reg
	public static boolean checkhid(int hid)
	{
		boolean temp=false;
		try 
		{
			PreparedStatement pst=con.prepareStatement("select hid from hotels where hid=?");
			pst.setInt(1, hid);
			ResultSet rs=pst.executeQuery();
			temp=rs.next();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return temp;
	}
	//bm1--for hotel reg
	public static int addHotelDetails(Hotel ob) 
	{
		int temp=0;
		try 
		{
			PreparedStatement pst=con.prepareStatement("insert into hotels values(?,?,?,?,?,?,?)");
			pst.setInt(1, ob.getHid());
			pst.setString(2, ob.getHname());
			pst.setString(3, ob.getHlocation());
			pst.setFloat(4, ob.getHfair());
			pst.setString(5, ob.getHmail());
			pst.setString(6, ob.getHpassword());
			pst.setLong(7, ob.getHcont());
			pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return temp;
	}	


//bm3
public static  Set<String> allHlocations(){
	Set<String> hs=null;
	try{
		PreparedStatement pst=con.prepareStatement("select hlocation from hotels");
		
		ResultSet rs=pst.executeQuery();
		hs=new HashSet<String> ();
		while(rs.next())
		{
			hs.add(rs.getString(1));
		}
			    
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return hs;
}
//bm4
public static List<Hotel> getAllHotelDetails(String x)
{
	 ArrayList<Hotel>  al=new ArrayList<Hotel>();  
    try
    {  
	        PreparedStatement ps=con.prepareStatement("select * from hotels where hlocation=?");
	        ps.setString(1, x);
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next())
	        {  
		
			Hotel ob=new Hotel();
			ob.setHid(rs.getInt("hid"));
			ob.setHname(rs.getString("hname"));
			ob.setHlocation(rs.getString("hlocation"));
			ob.setHfair(rs.getFloat("hfair"));
			ob.setHmail(rs.getString("hmail"));
			ob.setHpassword(rs.getString("hpassword"));
			ob.setHcont(rs.getLong("hcontact"));
			al.add(ob);
		}
			    
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return al;
}
//bm5
public static List<Hotel> getAllHotelDetailsBasedonPrice(String a,String b)
{
	 ArrayList<Hotel>  al=new ArrayList<Hotel>();  
    try
    {  
	        PreparedStatement ps=con.prepareStatement("select * from hotel where fair>=? and fair<=?");
	        ps.setString(1, a);
	        ps.setString(2, b);
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next())
	        {  
	        	Hotel ob=new Hotel();
	            ob.setHid(rs.getInt("hid"));
				ob.setHname(rs.getString("hname"));
				ob.setHlocation(rs.getString("hlocation"));
				ob.setHfair(rs.getFloat("hfair"));
				ob.setHmail(rs.getString("hmail"));
				ob.setHpassword(rs.getString("hpassword"));
				ob.setHcont(rs.getLong("hcontact"));
				al.add(ob);
		
	        }
	    }			
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return  al;
}

public static List<Hotel> sortByLocation()
{
	 ArrayList<Hotel>  al=new ArrayList<Hotel>();  
    try
    {  
	        PreparedStatement ps=con.prepareStatement("select * from hotel order by hlocation");
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next())
	        {  
	        	Hotel ob=new Hotel();
	            ob.setHid(rs.getInt("hid"));
				ob.setHname(rs.getString("hname"));
				ob.setHlocation(rs.getString("hlocation"));
				ob.setHfair(rs.getFloat("hfair"));
				ob.setHmail(rs.getString("hmail"));
				ob.setHpassword(rs.getString("hpassword"));
				ob.setHcont(rs.getLong("hcontact"));
				al.add(ob);
		
	            }
	    }			
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return  al;
}

public static List<Hotel> sortByFair()
{
	 ArrayList<Hotel>  al=new ArrayList<Hotel>();  
    try
    {  
	        PreparedStatement ps=con.prepareStatement("select * from hotel order by fair");
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next())
	        { 
	        	Hotel ob=new Hotel();
	            ob.setHid(rs.getInt("hid"));
				ob.setHname(rs.getString("hname"));
				ob.setHlocation(rs.getString("hlocation"));
				ob.setHfair(rs.getFloat("hfair"));
				ob.setHmail(rs.getString("hmail"));
				ob.setHpassword(rs.getString("hpassword"));
				ob.setHcont(rs.getLong("hcontact"));
				al.add(ob);
		
	             }
	    }			
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return  al;
}
public static List<Hotel> sortByHotelName()
{
	 ArrayList<Hotel>  al=new ArrayList<Hotel>();  
    try
    {  
	        PreparedStatement ps=con.prepareStatement("select * from hotel order by hname");
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next())
	        {  
	        	Hotel ob=new Hotel();
	            ob.setHid(rs.getInt("hid"));
				ob.setHname(rs.getString("hname"));
				ob.setHlocation(rs.getString("hlocation"));
				ob.setHfair(rs.getFloat("hfair"));
				ob.setHmail(rs.getString("hmail"));
				ob.setHpassword(rs.getString("hpassword"));
				ob.setHcont(rs.getLong("hcontact"));
				al.add(ob);
		   
	        }
	    }			
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return  al;
}
public static List<Hotel> printHotelDetails()
{
	 ArrayList<Hotel>  al=new ArrayList<Hotel>();  
    try
    {  
	        PreparedStatement ps=con.prepareStatement("select * from hotels ");
	        
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next())
	        {  
		
			Hotel ob=new Hotel();
			ob.setHid(rs.getInt("hid"));
			ob.setHname(rs.getString("hname"));
			ob.setHlocation(rs.getString("hlocation"));
			ob.setHfair(rs.getFloat("hfair"));
			ob.setHmail(rs.getString("hmail"));
			ob.setHpassword(rs.getString("hpassword"));
			ob.setHcont(rs.getLong("hcontact"));
			al.add(ob);
		}
			    
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return al;
}


public static int saveBooking(Hotel ob)
{
	int temp=0;
	try
	{
		PreparedStatement pst=con.prepareStatement("insert into booking values(?,?,?,?,?)");
		//set values
		
		pst.setInt(1, ob.getBookedby());
		pst.setInt(2, ob.getPeople());
		pst.setDate(3,Date.valueOf(ob.getDateofvisiting()));
		pst.setString(4, ob.getCheckintime());
		pst.setString(5, ob.getCheckouttime());
		//execute query
		temp=pst.executeUpdate();
	}
	catch(Exception e)
	{
		e.printStackTrace();

	}
	return temp;
}
public static boolean debitCard()
{
	boolean temp=false;
	try 
	{
		PreparedStatement pst=con.prepareStatement("insert into Debited values(?,?,?,?)");
		
		ResultSet rs=pst.executeQuery();
		temp=rs.next();
	} catch (Exception e) 
	{
		e.printStackTrace();
	}
	return temp;
	
}
public static boolean transactionDetails()
{
	boolean temp=false;
	try 
	{
		PreparedStatement pst=con.prepareStatement("insert into transaction values(?,?,?,?,?,?)");
		
		ResultSet rs=pst.executeQuery();
		temp=rs.next();
	} catch (Exception e) 
	{
		e.printStackTrace();
	}
	return temp;
	
}
}
